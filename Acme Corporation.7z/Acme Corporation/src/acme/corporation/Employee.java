/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acme.corporation;

/**
 *
 * @author JoséM
 */
public class Employee {

// … contract types (constants)
    public enum Contract {

        TEMPORARY(0),
        TRAINING(1),
        INDEFINITE(2);

        private int value;

        private Contract(int value) {
            this.value = value;
        }

        public int getValue() {
            return this.value;
        }

        @Override
        public String toString() {
            switch (this) {
                case TEMPORARY:
                    return "Temporary";
                case TRAINING:
                    return "Training";
                case INDEFINITE:
                    return "Indefinite";
                default:
                    return null;
            }
        }
    }

// … attributes
    private String name;
    private Contract contract;
    private int years;
    private String department;
// … constructor

    Employee() {
    }

    Employee(String name, Contract contract, int years, String department) {
        this.name = name;
        this.contract = contract;
        this.years = years;
        this.department = department;
    }
// … getters

    public String getName() {
        return name;
    }

    public Contract getContract() {
        return contract;
    }

    public int getYears() {
        return years;
    }

    public String getDepartment() {
        return department;
    }
// … setters

    public void setName(String name) {
        this.name = name;
    }

    public void setContract(Contract contract) {
        this.contract = contract;
    }

    public void setYears(int years) {
        this.years = years;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
// … getSalary method

// … toString method
    @Override
    public String toString() {  
        return name + ":" + department + "department, " + contract + " contract, " + years + "years in the company, salary of " + salary + "bitcoins";
    }

}
